from django.apps import AppConfig


class TopicosConfig(AppConfig):
    name = 'topicos'
